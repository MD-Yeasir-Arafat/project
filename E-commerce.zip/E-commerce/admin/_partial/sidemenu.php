

<nav class="navbar-default navbar-static-side" role="navigation">
            <!-- sidebar-collapse -->
            <div class="sidebar-collapse">
                <!-- side-menu -->
                <ul class="nav" id="side-menu">
                    <li>
                        <!-- user image section-->
                        <div class="user-section">
                            <div class="user-section-inner">
                                <img src="assets/img/user.jpg" alt="">
                            </div>
                            <div class="user-info">
                                <div>Brilliant <strong>IT</strong></div>
                                <div class="user-text-online">
                                    <span class="user-circle-online btn btn-success btn-circle "></span>&nbsp;Online
                                </div>
                            </div>
                        </div>
                        <!--end user image section-->
                    </li>
                    <li class="sidebar-search">
                        <!-- search section-->
                        <div class="input-group custom-search-form">
                            <input type="text" class="form-control" placeholder="Search...">
                            <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                        </div>
                        <!--end search section-->
                    </li>
                    <li class="selected">
                        <a href="index.php"><i class="fa fa-dashboard fa-fw"></i>Dashboard</a>
                    </li>
                    <!-- Category -->
                     <li>
                        <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Category<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="?route=pages/addcategory">Add Category</a>
                            </li>
                            <li>
                                <a href="?route=pages/viewCategory">View Category</a>
                            </li>
                            
                        </ul>
                       
                    </li>
                    <!-- End Category -->

                    <!-- Sub Category -->
                    <li>
                        <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Sub Category<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="?route=pages/addSubcategory">Add Sub Category</a>
                            </li>
                            <li>
                                <a href="?route=pages/viewsubCastegory">View Sub Category</a>
                            </li>
                            
                        </ul>
                        
                    </li>
                    <!-- End Sub Category -->
                    <!-- Item -->
                    <li>
                        <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Item<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="?route=pages/addItem">Add Item</a>
                            </li>
                            <li>
                                <a href="?route=pages/itemView">View Item</a>
                            </li>
                            
                        </ul>
                       
                    </li>
                     <!-- end item -->
                     <!-- product -->
                      <li>
                        <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Product<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="?route=pages/product">Add Product</a>
                            </li>
                            <li>
                                <a href="?route=pages/viewProduct">View Product</a>
                            </li>
                            
                        </ul>
                       
                    </li>
                    <!--end product  -->

                    <!-- customer -->
                    <li>
                        <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Login Customer<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="?route=pages/customer">Customer Information</a>
                            </li>
                            <li>
                                <a href="?route=pages/customerOrderList">Customer Order</a>
                            </li>
                            
                        </ul>
                       
                    </li>
                    
                    <!--end customer -->
                    <!-- local customer -->
                   <li>
                        <a href="#"><i class="fa fa-bar-chart-o fa-fw"></i>Without Login Customer<span class="fa arrow"></span></a>
                        <ul class="nav nav-second-level">
                            <li>
                                <a href="?route=pages/withoutloginCustomer">Customer Information</a>
                            </li>
                            
                            
                        </ul>
                       
                    </li>

                     <li>
                        <a href="?route=pages/pagesControl"><i class="fa fa-bar-chart-o fa-fw"></i>Pages Control<span class="fa arrow"></span></a>
                    </li>

                    <li>
                        <a href="?route=pages/ShowContactus"><i class="fa fa-bar-chart-o fa-fw"></i>Contact Visitor<span class="fa arrow"></span></a>
                    </li>
                    <!-- end local customer -->
                     <!--end product  -->
                 
                </ul>
                
            </div>
            
        </nav>
