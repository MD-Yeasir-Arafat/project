<?php
session_start();
if(isset($_SESSION['logstatus'])){
    if($_SESSION['logstatus']==true){
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboad </title>
    <!-- Core CSS - Include with every page -->
    <link href="assets/plugins/bootstrap/bootstrap.css" rel="stylesheet" />
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="assets/plugins/pace/pace-theme-big-counter.css" rel="stylesheet" />
    <link href="assets/css/style.css" rel="stylesheet" />
    <link href="assets/css/main-style.css" rel="stylesheet" />
    <!-- Page-Level CSS -->
    <link href="assets/plugins/morris/morris-0.4.3.min.css" rel="stylesheet" />
    <link href="assets/plugins/dataTables/dataTables.bootstrap.css" rel="stylesheet" />
   </head>
<body>
    <!--  wrapper -->
    <div id="wrapper">
        <!-- navbar top -->
        <?php include '_partial/navbar.php';?>
        <!-- end navbar top -->

        <!-- navbar side -->
            <?php include '_partial/sidemenu.php';?>
        <!-- end navbar side -->
        
        <!--  page-wrapper -->
        <div id="page-wrapper">
        
            <?php
                if(isset($_GET['route'])){

                    $page=$_GET['route'].".php";

                    if(file_exists($page)){

                        include $page;

                    }else{

                        echo include '_partial/404.php';
                    }

                }else{
                    include '_partial/mainContent.php';
                }

            ?>

            </div>
        <!-- end page-wrapper -->
        <?php include '_partial/modal.php';?>
    </div>
    <!-- end wrapper -->

    <!-- Core Scripts - Include with every page -->
    <script src="assets/plugins/jquery-1.10.2.js"></script>
    <script src="assets/plugins/bootstrap/bootstrap.min.js"></script>
    <script src="assets/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="assets/plugins/pace/pace.js"></script>
    <script src="assets/scripts/siminta.js"></script>
    <!-- Page-Level Plugin Scripts-->
    <script src="assets/plugins/morris/raphael-2.1.0.min.js"></script>
    <script src="assets/plugins/morris/morris.js"></script>
    <script src="assets/scripts/dashboard-demo.js"></script>

    <script src="assets/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="assets/plugins/dataTables/dataTables.bootstrap.js"></script>
  

</body>

</html>
<?php
}else{
    $_SESSION['mass']='Email or Password not match and not activated';
    header('location:login.php');
}
}else{
    $_SESSION['mass']='Email or Password not match and not activated';
    header('location:login.php');
}

?>
