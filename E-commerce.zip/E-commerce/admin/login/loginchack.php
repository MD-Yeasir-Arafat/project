<?php
session_start();
include '../../db/db.php';
if(isset($_POST['check'])){

 $email=$_POST['email'];
 $password=$_POST['password'];
 $pass=md5($password);
 $query="SELECT * FROM admin WHERE status=1";
 $select=mysqli_query($db,$query);
 $fetch=mysqli_fetch_assoc($select);
 if($email==$fetch['email'] && $pass==$fetch['password']){
 	$_SESSION['logstatus']=true;
 	header('location:../index.php');
 }else{
 	$_SESSION['logstatus']=false;
 	$_SESSION['mess']='Email or Password not match and not activated';
 	header('location:../login.php');
 }
}

?>