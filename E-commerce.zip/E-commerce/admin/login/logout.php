<?php
session_start();
$status=$_GET['status'];

if($status){
	$_SESSION['logstatus']=false;
	$_SESSION['mass']="logout Success";
	header('location:../login.php');
}
?>