 <?php
include '../db/db.php';
$id=$_GET['id'];
$sql="SELECT * FROM banner WHERE id=$id";
$select=mysqli_query($db,$sql);
$data=mysqli_fetch_assoc($select);
 ?>

 <div class="row">
    <!-- Page Header -->
	<div class="col-lg-12">
	    <h1 class="page-header">Edit Banner</h1>

	    <div class="col-lg-6">
	    	<form action="pages/banner/editBanner.php" method="post" enctype="multipart/form-data">
              <div class="row">
                <div class="col">
                	<input type="hidden" name="id" value="<?php echo $data['id']?>">
                  <input type="text" name="title" class="form-control" placeholder="Banner Title" required="" value="<?php echo $data['banner_title']?>"><br>
                  <input type="text" name="discount" class="form-control" placeholder="Discount" required="" value="<?php echo $data['discount']?>"><br>
                  <input name="image" type="file"  class="form-control" required="">
                </div><br>
                <center>
                    <button name="banner" class="btn btn-success">Save</button>
                    
                </center>
              </div>
            </form>
	    </div>
	</div>
	<!--End Page Header -->
</div>