<?php
include '../db/db.php';
$value=$_GET['id'];
$querySr="SELECT item.*, category.category_name,sub_cetagory.sub_cetagory_name FROM item LEFT JOIN category ON item.fk_cetagory_id = category.id LEFT JOIN sub_cetagory ON item.sub_cetagory_id=sub_cetagory.id WHERE item.id=$value";
$selectItem=mysqli_query($db,$querySr);
$fetch=mysqli_fetch_assoc($selectItem);

?>