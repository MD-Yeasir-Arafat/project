<?php
session_start();
include '../../../db/db.php';
 $id=$_GET['id'];

$query="DELETE FROM item WHERE id=$id";
$delete=mysqli_query($db,$query);
if($delete > 0){
	$_SESSION['message']='Data has been delete';
	header('location:../../?route=pages/itemView');
}else{
	$_SESSION['message']='Data not deleted';
	header('location:../../?route=pages/itemView');
}
?>