<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['save'])){
$catId=$_POST['category'];
$subID=$_POST['subcat'];
$item=$_POST['item'];

$query="INSERT INTO item(fk_cetagory_id,sub_cetagory_id,item_name,status) VALUES ('$catId','$subID','$item',1)";
$insert=mysqli_query($db,$query);
if($insert > 0){
	$_SESSION['message']='Data has been Insert';
	header('location:../../?route=pages/addItem');
}else{
	$_SESSION['message']='Data not Inserted';
	header('location:../../?route=pages/addItem');
}

}
?>