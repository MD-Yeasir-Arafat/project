<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['save'])){
	 $id=$_POST['id'];
	 $catID=$_POST['category'];
	 $SubcatID=$_POST['subcat'];
	 $item=$_POST['item'];

	$query="UPDATE item SET fk_cetagory_id='$catID',sub_cetagory_id='$SubcatID',item_name='$item' WHERE id='$id'";
	$update=mysqli_query($db,$query);
	if($update > 0){
		$_SESSION['message']='Data has been update';
		header('location:../../?route=pages/itemView');
	}else{
		$_SESSION['message']='Data not updated';
		header('location:../../?route=pages/itemView');
	}
}

?>