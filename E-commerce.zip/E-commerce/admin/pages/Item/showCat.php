<?php
include '../db/db.php';
$catQuery="SELECT * FROM category WHERE status=1";
$showCategory=mysqli_query($db,$catQuery);
?>