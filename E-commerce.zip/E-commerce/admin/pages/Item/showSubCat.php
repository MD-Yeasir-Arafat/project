<?php
include '../../../db/db.php';
$id=$_POST['id'];
$query="SELECT category.category_name, sub_cetagory.* FROM sub_cetagory LEFT JOIN category ON sub_cetagory.fk_cetagory_id=category.id WHERE sub_cetagory.fk_cetagory_id=$id";
$selectSub=mysqli_query($db,$query);

?>
<?php while($data3=mysqli_fetch_assoc($selectSub)){?>
<option value="<?php echo $data3['id']?>"><?php echo $data3['sub_cetagory_name']?></option>
<?php }?>