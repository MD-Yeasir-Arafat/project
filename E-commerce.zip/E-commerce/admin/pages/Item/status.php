<?php
session_start(); 
include '../../../db/db.php';
$id=$_GET['id'];
$status=$_GET['status'];

if($status=='inactive'){
	$query="UPDATE item SET status=0 WHERE id=$id";
	$update=mysqli_query($db,$query);
	if($update > 0){
		$_SESSION['message']='Data has been Update';
		header('location:../../?route=pages/itemView');
	}else{
		$_SESSION['message']='Data not Updated';
		header('location:../../?route=pages/itemView');
	}
}

if($status=='active'){
	$query="UPDATE item SET status=1 WHERE id=$id";
	$update=mysqli_query($db,$query);
	if($update > 0){
		$_SESSION['message']='Data has been Update';
		header('location:../../?route=pages/itemView');
	}else{
		$_SESSION['message']='Data not Updated';
		header('location:../../?route=pages/itemView');
	}
}

?>