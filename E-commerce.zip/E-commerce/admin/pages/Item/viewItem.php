<?php
include '../db/db.php';
$query="SELECT category.category_name, sub_cetagory.sub_cetagory_name,
		item.* FROM item LEFT JOIN category ON item.fk_cetagory_id=category.id 
		LEFT JOIN sub_cetagory ON item.sub_cetagory_id=sub_cetagory.id";
		$select=mysqli_query($db,$query);
?>