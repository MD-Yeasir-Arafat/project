$(document).ready(function(){
	$('#catID').change(function(){
		var value=$(this).val();
		//alert(value);
		if(value == 0){
			$('#subcat').hide();
		}else{
			$('#subcat').show();
			$.post('pages/Item/showSubCat.php',{id:value},function(data){
				$('#subcat').html(data);
			});
			
		}
	})
})