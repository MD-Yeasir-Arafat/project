$(document).ready(function(){
	$('#catID').change(function(){
		var id=$(this).val();
		//alert(id);
		if(id==0){
			$('#subcat').hide();
		}else{
			$('#subcat').show();
			$.post('pages/product/showsubcat.php',{id:id},function(value){
				$('#subcat').html(value);
			});
		}
	})
})