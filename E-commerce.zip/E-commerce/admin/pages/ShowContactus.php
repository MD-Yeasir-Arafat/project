<?php
include 'contactus/viewContactus.php';
?>

<div class="row">
    <!-- Page Header -->
    <div class="col-lg-12">
        <h1 class="page-header">Contact Us pepole</h1>
    </div>
    <!--End Page Header -->


		 <table class="table">
		  <thead>
		    <tr>
		      <th scope="col">No.</th>
		      <th scope="col">First</th>
		      <th scope="col">Last</th>
		      <th scope="col">email</th>
		      <th scope="col">Phone</th>
		      <th scope="col">Comments</th>
		      <th scope="col">When Contact us</th>
		    </tr>
		  </thead>
		  <tbody>
		  	<?php 
		  	while($data=mysqli_fetch_assoc($select)){
		  	?>
		    <tr>
		      <td><?php echo $data['id']?></td>
		      <td><?php echo $data['first_name']?></td>
		      <td><?php echo $data['last_name']?></td>
		      <td><?php echo $data['email']?></td>
		      <td><?php echo $data['tel']?></td>
		      <td><?php echo $data['message']?></td>
		      <td><?php echo $data['time']?></td>
		    </tr>
		   <?php }?>
		  </tbody>
		</table>
</div>