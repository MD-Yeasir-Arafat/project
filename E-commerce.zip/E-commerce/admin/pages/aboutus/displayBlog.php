<?php
include '../db/db.php';
$sql="SELECT * FROM aboutus_blog";
$select=mysqli_query($db,$sql);
?>