<?php
include '../db/db.php';
$sql="SELECT * FROM aboutus";
$select=mysqli_query($db,$sql);

?>