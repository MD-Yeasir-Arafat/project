<?php
include 'getBlog.php';
?>
<h4>Edit Category</h4>
<form action="pages/aboutus/updateBlog.php" method="POST">
	<input type="hidden" name="id" value="<?php echo $data['id']?>">
	
	<textarea name="blog" rows="10" cols="40"><?php echo $data['blog']?></textarea>
	<div><input type="submit" name="submit" value="update" class="btn btn-success"></div>
	
</form>