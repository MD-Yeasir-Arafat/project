<?php
include 'getPerson.php';
?>
<h4>Edit Category</h4>
<form action="pages/aboutus/updatePerson.php" method="POST" enctype="multipart/form-data">
	<input type="hidden" name="id" value="<?php echo $data['id']?>">
	
	<input type="text" name="name" value="<?php echo $data['person_name']?>"><br>
	<input type="text" name="position" value="<?php echo $data['person_position']?>"><br>
	<input type="file" name="image"><br>

	<div><input type="submit" name="submit" value="update" class="btn btn-success"></div>
	
</form>