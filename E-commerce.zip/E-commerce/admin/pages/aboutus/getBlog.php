<?php
include '../../../db/db.php';
 $catId=$_GET['id'];
$qquery="SELECT * FROM aboutus_blog WHERE id=$catId";
$serch=mysqli_query($db,$qquery);
$data=mysqli_fetch_assoc($serch);
?>