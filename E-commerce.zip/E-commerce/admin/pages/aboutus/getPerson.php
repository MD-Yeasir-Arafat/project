<?php
include '../../../db/db.php';
$id=$_GET['id'];
$sql="SELECT * FROM aboutus WHERE id='$id'";
$select=mysqli_query($db,$sql);
$data=mysqli_fetch_assoc($select);
?>