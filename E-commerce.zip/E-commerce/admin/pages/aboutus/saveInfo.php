<?php 
session_start();
include '../../../db/db.php';
if(isset($_POST['aboutus'])){
	 $blog=$_POST['description'];
	$sql="INSERT INTO aboutus_blog (blog,status) VALUES ('$blog',1)";
	//exit();
	$insert=mysqli_query($db,$sql);
	if($insert > 0){
		$_SESSION['message']='Data has been insert';
		header('location:../../?route=pages/pagesControl');
	}else{
		$_SESSION['message']='Data not inserted';
		header('location:../../?route=pages/pagesControl');
	}
}

if(isset($_POST['person'])){

	 $name=$_POST['name'];
	 $position=$_POST['position'];

	 $imageName=$_FILES['image']['name'];
	 $imageSize=$_FILES['image']['size'];

	 if($imageSize < 2500000){
	 	$path="../../../aboutus_image/$imageName";
	 	$up=move_uploaded_file($_FILES['image']['tmp_name'],$path);

	 	if($up > 0){

	 	  $sql="INSERT INTO aboutus(person_name, person_position, person_image, status) VALUES ('$name','$position','$imageName',1)";
	 	  echo $insert=mysqli_query($db,$sql);
	 	  
	 	  if($insert > 0){
	 	  	$_SESSION['message']='Data has been insert';
	 	  	header('location:../../?route=pages/pagesControl');
	 	  }else{
	 	  	$_SESSION['message']='Data not inserted';
	 	  	header('location:../../?route=pages/pagesControl');
	 	  }
	 	}
	 }
}

?>