<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['submit'])){
	$id=$_POST['id'];
	$blog=$_POST['blog'];

	$sql="UPDATE aboutus_blog SET blog='$blog' WHERE id=$id";
	$update=mysqli_query($db,$sql);

	if($update > 0){
		$_SESSION['message']='Data has been update';
		header('location:../../?route=pages/viewBlog');
	}else{
		$_SESSION['message']='Data not updated';
		header('location:../../?route=pages/viewBlog');
	}
}

?>