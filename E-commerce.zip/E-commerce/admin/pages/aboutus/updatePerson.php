<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['submit'])){
	$id=$_POST['id'];
	$name=$_POST['name'];
	$position=$_POST['position'];
	
	 $imageName=$_FILES['image']['name'];

	 $imageSize=$_FILES['image']['size'];
	 if( $imageSize < 2500000){
	 	$path="../../../aboutus_image/$imageName";
	 	$up=move_uploaded_file($_FILES['image']['tmp_name'],$path);
	 	if($up > 0){
	 		$sql="UPDATE aboutus SET person_name='$name',person_position='$position',person_image='$imageName' WHERE id=$id";
	 		$update=mysqli_query($db,$sql);
	 		if($update > 0){
	 			$_SESSION['message']='Data has been update';
	 			header('location:../../?route=pages/viewPerson');
	 		}else{
	 			$_SESSION['message']='Data not updated';
	 			header('location:../../?route=pages/viewPerson');
	 		}
	 	}

	 }

}

?>