<?php
include 'Item/showCat.php';
 ?>
 <div class="row">
                 <!-- page header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Add Item Page</h1>
                    
                </div>
                <!--end page header -->
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         <?php
                                if(isset($_SESSION['message'])){
                               echo "<span style='color: red;'>".$_SESSION["message"]."</span>";
                               unset($_SESSION["message"]);
                                   
                                }

                            ?>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-lg-6">
                                    
                                    <form action="pages/Item/saveItem.php" method="post"> 
                                        <div class="form-group">
                                            <label>Category Name:</label>
                                            <select id="catID" name="category" class="form-control" required="">
                                                <option value="0">Select Category </option>
                                                <?php while($data=mysqli_fetch_assoc($showCategory)){?>
                                                <option value="<?php echo $data['id']?>"><?php echo $data['category_name']?></option>
                                                <?php }?>
                                            </select>
                                            
                                        </div>
                                        <div class="form-group">
                                            <label>Sub Category Name:</label>
                                            <select id="subcat" name="subcat" style="display: none;" class="form-control" required="">
                                                
                                            </select>
                                        </div>
                                        <div class="form-group">
                                            <label>Item Name:</label>
                                            <input name="item" class="form-control" required="">
                                        </div>
                                        <button name="save" type="submit" class="btn btn-primary">Insert</button>
                                    </form>
                                </div>
                               
                            </div>
<script type="text/javascript" src="pages/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="pages/Scat.js"></script>