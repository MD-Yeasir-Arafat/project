<?php
session_start();
include '../../../db/db.php';
$id=$_GET['id'];
$status=$_GET['status'];

if($status == 'deactive'){
	$sql="UPDATE banner SET status=0 WHERE id=$id";
	$update=mysqli_query($db,$sql);

	if($update>0){
		$_SESSION['message']='Data has been update';
		header('location:../../?route=pages/viewBanner');
	}else{
		$_SESSION['message']='Data not updated';
		header('location:../../?route=pages/viewBanner');
	}
}

if($status == 'active'){
	$sql="UPDATE banner SET status=1 WHERE id=$id";
	$update=mysqli_query($db,$sql);

	if($update>0){
		$_SESSION['message']='Data has been update';
		header('location:../../?route=pages/viewBanner');
	}else{
		$_SESSION['message']='Data not updated';
		header('location:../../?route=pages/viewBanner');
	}
}



?>