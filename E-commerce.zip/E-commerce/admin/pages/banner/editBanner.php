<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['banner'])){
	$id=$_POST['id'];
	$title=$_POST['title'];
	$discount=$_POST['discount'];

	$imageName=$_FILES['image']['name'];
	$imageSize=$_FILES['image']['size'];
	$imageType=$_FILES['image']['type'];
	 if($imageType != "image/jpeg" && $imageType != "image/png" && $imageType != "jpg"){

	 	$_SESSION['message']='Sorry! File only allowed jpg png or jped';
	 	header('location:../../?route=pages/viewBanner');
	 	
	 }else{
	 	 if($imageSize < 5000000){
	 	 	$path="../../../bannerimage/$imageName";
	 		$up=move_uploaded_file($_FILES['image']['tmp_name'],$path);
	 		if($up > 0){

	 		 $sql="UPDATE banner SET banner_title='$title',discount='$discount',image='$imageName',status=1 WHERE id=$id";
	 		
	 		$update=mysqli_query($db,$sql);

	 		if($update > 0){
	 			$_SESSION['message']='Data has been update';
	 			header('location:../../?route=pages/viewBanner');
	 		}else{
	 			$_SESSION['message']='Data not updated';
	 			header('location:../../?route=pages/viewBanner');
	 		}
	 	}
	 }
	 }

	
}
?>