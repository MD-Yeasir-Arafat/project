<?php
session_start();
include '../../../db/db.php';

if(isset($_POST['banner'])){
	$title=$_POST['title'];
	$discount=$_POST['discount'];

	 $imageName=$_FILES['image']['name'];
	 $imageSize=$_FILES['image']['size'];
	 $imagetype=$_FILES['image']['type'];

	 if($imagetype != "image/jpeg" && $imagetype != "image/png" && $imagetype != "jpg"){
	 	
	 	$_SESSION['message']='Sorry! File only allowed jpg png or jped';
	 	header('location:../../?route=pages/pagesControl');
	 }else{
	 if($imageSize < 5000000){
	 	$path="../../../bannerimage/$imageName";
	 	$up=move_uploaded_file($_FILES['image']['tmp_name'],$path);

	 	if($up > 0){
	 		$sql="INSERT INTO banner (banner_title, discount, image, status) VALUES ('$title','$discount','$imageName',1)";
	 		$insert=mysqli_query($db,$sql);

	 		if($insert > 0){
	 			$_SESSION['message']='Data has been Upload';
	 			header('location:../../?route=pages/pagesControl');
	 		}else{
	 			$_SESSION['message']='Data not Uploaded';
	 			header('location:../../?route=pages/pagesControl');
	 		}
	 	}
	 }
}
	 }

	
?>