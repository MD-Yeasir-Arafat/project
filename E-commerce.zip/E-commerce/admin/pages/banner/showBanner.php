<?php
include '../db/db.php';
$sql="SELECT * FROM banner";
$select=mysqli_query($db,$sql);

?>