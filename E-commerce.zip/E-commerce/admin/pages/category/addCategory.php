<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['save'])){
	  $value=$_POST['category'];
	
	$query="INSERT INTO category(category_name,status) VALUES ('$value',1)";
	$insert=mysqli_query($db,$query);
	if($insert > 0){
		$_SESSION["message"]="Data has been Insert";
		header('location:../../?route=pages/addcategory');
	}else{
		$_SESSION["message"]="Data not Insert";
		header('location:../../?route=pages/addcategory');
	}

}
?>