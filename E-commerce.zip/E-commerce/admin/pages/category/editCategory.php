<?php
include 'getCat.php';
?>
<h4>Edit Category</h4>
<form action="pages/category/updateCat.php" method="POST">
	<input type="hidden" name="id" value="<?php echo $data['id']?>">
	<input type="text" name="editcatname" value="<?php echo $data['category_name']?>">
	<input type="submit" name="submit" value="update">
</form>
