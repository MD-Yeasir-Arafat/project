<?php
include '../../../db/db.php';
 $catId=$_GET['id'];
$qquery="SELECT * FROM category WHERE id=$catId";
$serch=mysqli_query($db,$qquery);
$data=mysqli_fetch_assoc($serch);
?>