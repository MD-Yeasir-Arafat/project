<?php
session_start();
include '../../../db/db.php';
 $id=$_GET['id'];
 $status=$_GET['status'];
  if($status == 'inactive'){
  	$query="UPDATE category SET status=0 WHERE id=$id";
  	$update=mysqli_query($db,$query);
  	if($update > 0){
  		$_SESSION['message']='Data has been Update';
  		header('location:../../?route=pages/viewCategory');
  	}else{
  		$_SESSION['message']='Data not Update';
  		header('location:../../?route=pages/viewCategory');
  	}
  }

  if($status == 'active'){
  	$query="UPDATE category SET status=1 WHERE id=$id";
  	$update=mysqli_query($db,$query);
  	if($update > 0){
  		$_SESSION['message']='Data has been Update';
  		header('location:../../?route=pages/viewCategory');
  	}else{
  		$_SESSION['message']='Data not Update';
  		header('location:../../?route=pages/viewCategory');
  	}
  }




?>