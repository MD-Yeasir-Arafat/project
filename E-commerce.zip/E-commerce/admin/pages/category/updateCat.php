<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['submit'])){

$id=$_POST['id'];
$catnam=$_POST['editcatname'];

$query="UPDATE category SET category_name='$catnam' WHERE id=$id";
$update=mysqli_query($db,$query);
if($update > 0)
{
	$_SESSION['message']='Data has been Update';
	header('location:../../?route=pages/viewCategory');
}else{
	$_SESSION['message']='Data not Update';
	header('location:../../?route=pages/viewCategory');
}
}
?>