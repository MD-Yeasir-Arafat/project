<?php
include '../db/db.php';
$query="SELECT * FROM category";
$select=mysqli_query($db,$query);
?>