<?php
include '../db/db.php';

$sql="SELECT * FROM contactus";
$select=mysqli_query($db,$sql);

?>