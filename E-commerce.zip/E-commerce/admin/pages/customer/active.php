<?php 
session_start();
include '../../../db/db.php';
 $email=$_GET['email'];
 $id=$_GET['id'];
 $status=$_GET['status'];
 if($status == 'inactive'){
 	$sql="UPDATE customerorder SET status=0 WHERE id=$id";
 	$update=mysqli_query($db,$sql);
 	if($update > 0){
 		$_SESSION['message']='Order Complete';
 		header("location:../../?route=pages/singlecustomerorderlist&&email=".$email."");
 	}else{
 		$_SESSION['message']='Data not update';
 		header("location:../../?route=pages/singlecustomerorderlist&&email=".$email."");
 	}
 }
if($status == 'active'){
 	$sql="UPDATE customerorder SET status=1 WHERE id=$id";
 	$update=mysqli_query($db,$sql);
 	if($update > 0){
 		$_SESSION['message']='Order Complete';
 		header("location:../../?route=pages/singlecustomerorderlist&&email=".$email."");
 	}else{
 		$_SESSION['message']='Data not update';
 		header("location:../../?route=pages/singlecustomerorderlist&&email=".$email."");
 	}
 }



?>