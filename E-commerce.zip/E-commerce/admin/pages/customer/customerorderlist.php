<?php
include '../db/db.php';
$sql="SELECT * FROM customerorder";
$query=mysqli_query($db,$sql);
$a=0;

while($data=mysqli_fetch_assoc($query)){
	$a++;
	$proID=$data['product_id'];
	$product="SELECT * FROM product WHERE id=$proID";
	$pro[$a]=mysqli_query($db,$product);
}

?>