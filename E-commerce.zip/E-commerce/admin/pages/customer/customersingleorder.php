<?php
include '../db/db.php';
$email=$_GET['email'];

$sql="SELECT * FROM customerorder WHERE email='$email'";
$query=mysqli_query($db,$sql);
$a=0;
while($data=mysqli_fetch_assoc($query)){
	$a++;
	$proID=$data['product_id'];
	$sql2="SELECT * FROM product WHERE id=$proID";
	$product[$a]=mysqli_query($db,$sql2);
}

?>