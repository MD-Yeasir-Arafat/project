<?php 
include 'customer/customerorderlist.php';
?>

<div class="row">
                <!--page header-->
                <div class="col-lg-12">
                    <h1 class="page-header">customer order list</h1>
                </div>
                 <!--end page header-->
            </div>
            <?php
            mysqli_data_seek($query,0);
            $i=0;
            while($order=mysqli_fetch_assoc($query)){
              $i++;
           ?>
  <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-default">
             
              <div class="panel-body">
          
          <form>
              <div class="form-row">
                <div class="form-group">
                  <center><label for="inputAddress">Email</label></center>
                  <center><input type="email" class="form-control" id="inputEmail4" value="<?php echo $order['email']?>" style="width: 500px; text-align: center;" readonly></center>
               </div>
                
              </div>
               
                 <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">SL</th>
                          <th scope="col">Product Picture</th>
                          <th scope="col">Product Name</th>
                          <th scope="col">price</th>
                          <th scope="col">quantity</th>
                          <th scope="col">sub Total</th>
                          <th scope="col">order time</th>
                          <th scope="col">Action</th>

                        </tr>
                      </thead>
                      <tbody>
                        <?php
                          while ($order1=mysqli_fetch_assoc($pro[$i])) {
                           
                        ?>
                        <tr>
                          <td><?php echo $order['id']?></td>
                          <td><img src="../product_image/<?php echo $order1['image']?>" height="80" width="100"></td>
                          <td style="width: 250px;"><?php echo $order1['product_name']?></td>
                          <td><input type="text" readonly value="<?php echo $order1['product_price']?>" style="width:100px;"></td>
                          <td><input type="text" readonly value="<?php echo $order['quentity']?>" style="width:100px;"></td>
                          <td><input type="text" readonly value="<?php echo $order['quentity']*$order1['product_price']?>" style="width:100px;"></td>
                          <td><?php echo $order['created_at']?></td>
                          <td></td>
                        </tr>
                        <?php }?>
                      </tbody>
                    </table>
            </form>
                          
            </div>
              
        </div>
    </div>
</div>
<?php }?>

