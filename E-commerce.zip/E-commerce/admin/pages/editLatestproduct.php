 <?php include 'latestProduct/ShowEdit.php';?>
 <div class="row">
                 <!-- page header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Latest Product </h1>
                    
                </div>
                <!--end page header -->
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            
                            <?php
                                if(isset($_SESSION['message'])){
                               echo "<span style='color: red;'>".$_SESSION["message"]."</span>";
                               unset($_SESSION["message"]);
                                   
                                }

                            ?>
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form action="pages/latestProduct/saveEditproduct.php" role="form" method="post" enctype="multipart/form-data">
                               <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Image:</label>
                                            <img src="../product_image/<?php echo $data['product_image']?>" height="80">
                                        </div>
                                </div>
                              
                                
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Name:</label>
                                            <input name="product_name" class="form-control" required="" value="<?php echo $data['product_name']?>">
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Details:</label>
                                            <textarea name="product_details" class="form-control" cols="30" rows="5" required=""><?php echo $data['details']?></textarea>
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Price:</label>
                                            <input name="price" class="form-control" type="number" required="" value="<?php echo $data['product_price']?>">
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Size:</label>
                                            <input name="size" class="form-control" type="text" value="<?php echo $data['product_size']?>">
                                        </div>
                                </div>
                                 <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Color:</label>
                                            <input name="color" class="form-control" type="color" value="<?php echo $data['product_color']?>">
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product image:</label>
                                            <input name="image" class="form-control" type="file" required="">
                                        </div>
                                </div>
                                    <input name="id" type="hidden" value="<?php echo $data['id']?>">
                                 <div class="col-lg-3">
                                    <button name="save" type="submit" class="btn btn-danger">Insert</button>
                                </div>

                               </form>
                            </div>
                        </div>
                    </div>
                     <!-- End Form Elements -->
                </div>
            </div>
