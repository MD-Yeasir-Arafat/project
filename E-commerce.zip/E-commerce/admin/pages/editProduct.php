 <?php 
include 'product/showCat.php';
include 'product/productedit.php';

 ?>
 <div class="row">
                 <!-- page header -->
                <div class="col-lg-12">
                    <h1 class="page-header">Edit Product Page</h1>
                    
                </div>
                <!--end page header -->
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <!-- Form Elements -->
                    <div class="panel panel-default">
                        <div class="panel-heading">
                         
                        </div>
                        <div class="panel-body">
                            <div class="row">
                                <form action="pages/product/updateProduct.php" role="form" method="post" enctype="multipart/form-data">
                                <div class="col-lg-3">
                                    <input name="productID" type="hidden" value="<?php echo $datashow['id']?>">
                                        <div class="form-group">
                                            <label>Category Name:</label>
                                            <select id="catID" name="cat" class="form-control" required="">
                                                <option value="0">Select category</option>
                                                <?php while($data1=mysqli_fetch_assoc($selectCat)){?>
                                                <option value="<?php echo $data1['id']?>"><?php echo $data1['category_name']?></option>
                                                <?php }?>
                                            </select>
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Sub Category Name:</label>
                                            <select id="subcat" name="subcat" class="form-control" style="display: none;" required="">
                                                
                                            </select>
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Item Name:</label>
                                            <select id="item" name="item" class="form-control" style="display: none;" required="">
                                                
                                            </select>
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Name:</label>
                                            <input name="productname" class="form-control"  value="<?php echo $datashow['product_name']?>">
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Details:</label>
                                            <textarea name="product_details" class="form-control" cols="30" rows="5" required=""><?php echo $datashow['product_details']?></textarea>
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Price:</label>
                                            <input name="price" class="form-control" type="number" required="" value="<?php echo $datashow['product_price']?>" >
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Size:</label>
                                            <input name="size" class="form-control" type="text" value="<?php echo $datashow['product_size']?>">
                                        </div>
                                </div>
                                 <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product Color:</label>
                                            <input name="color" class="form-control" type="color">
                                        </div>
                                </div>
                                <div class="col-lg-3">
                                        <div class="form-group">
                                            <label>Product image:</label>
                                            <input name="image" class="form-control" type="file" required="">
                                        </div>
                                </div>
                                
                                 <div class="col-lg-3">
                                    <button name="update" type="submit" class="btn btn-danger">Update</button>
                                </div>

                               </form>
                            </div>
                        </div>
                    </div>
                     <!-- End Form Elements -->
                </div>
            </div>
<script type="text/javascript" src="pages/jquery-3.3.1.min.js"></script>
<script type="text/javascript" src="pages/Scat2.js"></script>
<script type="text/javascript" src="pages/itemid.js"></script>