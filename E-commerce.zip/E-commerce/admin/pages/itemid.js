$(document).ready(function(){
	$('#subcat').change(function(){
		var id=$(this).val();
		if(id == 0){
			$('#item').hide();
		}else{
			$('#item').show();
			$.post('pages/product/showItem.php',{id:id},function(value){
				$('#item').html(value);
			});
		}
	})
})