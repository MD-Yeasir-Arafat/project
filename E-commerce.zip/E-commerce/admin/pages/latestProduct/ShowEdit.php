<?php
include '../db/db.php';
$id=$_GET['id'];
$query="SELECT * FROM latest_product WHERE id=$id";
$showQuery=mysqli_query($db,$query);
$data=mysqli_fetch_assoc($showQuery);
?>