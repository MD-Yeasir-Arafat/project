<?php
include '../db/db.php';
$query="SELECT * FROM latest_product";
$select=mysqli_query($db,$query);
?>