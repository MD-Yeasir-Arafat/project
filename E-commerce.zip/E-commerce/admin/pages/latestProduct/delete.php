<?php
session_start();
include '../../../db/db.php';
$id=$_GET['id'];
$query="DELETE FROM latest_product WHERE id=$id";
$delete=mysqli_query($db,$query);
if($delete > 0){
	$_SESSION['message']='Data has been Delete';
	header('location:../../?route=pages/viewLatestProduct');
}else{
	$_SESSION['message']='Data not Deleted';
	header('location:../../?route=pages/viewLatestProduct');
}
?>