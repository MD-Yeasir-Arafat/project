<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['save'])){
	foreach ($_POST as $key => $value) {
		$$key=$value;
	}

	$image=$_FILES['image'];
	$imageSize=$_FILES['image']['size'];
	if($imageSize < 1000000){
		$date= date('hms');
		$imageFile=$date.'.jpg';
		$path="../../../product_image/$imageFile";
		$uplode=move_uploaded_file($_FILES['image']['tmp_name'],$path);
		if($uplode > 0){
			$query="INSERT INTO latest_product(product_name,details,product_price,product_size,product_color,product_image,status) VALUES ('$product_name','$product_details','$price','$size','$color','$imageFile',1)";
			$insert=mysqli_query($db,$query);
			if($insert > 0){
				$_SESSION['message']='Data has been insert';
				header('location:../../?route=pages/latestProduct');
			}else{
				$_SESSION['message']='Data not inserted';
				header('location:../../?route=pages/latestProduct');
			}
		}
	}else{
		$_SESSION['message']='The file is large';
		header('location:../../?route=pages/latestProduct');
	}
}
?>