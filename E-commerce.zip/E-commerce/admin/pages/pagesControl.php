<div class="row">
                 <!-- page header -->
                <div class="col-lg-12">
                    <h1 class="page-header">pages Controll <center><span>
                        <?php 
                        if(isset($_SESSION['message'])){
                            echo $_SESSION['message'];
                        }
                        unset($_SESSION['message']);
                        ?>
                    </span></center></h1>
                </div>
                <!--end page header -->
            </div>
            <div class="row">
                
                    <!-- Form Elements -->
                    <div class="col-lg-6">
                         <form action="pages/aboutus/saveInfo.php" method="post">
                             Blog : <br />
                             <textarea rows = "10" cols = "60" name ="description"></textarea>
                             <div>
                                <center>
                                    <button name="aboutus" class="btn btn-success">save</button>
                                     <a href="?route=pages/viewBlog" class="btn btn-success">View</a>
                                </center>
                            </div>
                             
                          </form>
                    </div>
                     <div class="col-lg-6">
                        <form action="pages/aboutus/saveInfo.php" method="post" enctype="multipart/form-data">
                          <div class="row">
                            <div class="col">
                              <input type="text" name="name" class="form-control" placeholder="Person name"><br>
                              <input type="text" name="position" class="form-control" placeholder="Person Position"><br>
                              <input name="image" type="file"  class="form-control">
                            </div><br>
                            <center>
                                <button name="person" class="btn btn-success">Save</button>
                                <a href="?route=pages/viewPerson" class="btn btn-success">View</a>

                            </center>
                          </div>
                        </form>
                    </div>

                    
                      <div class="container">
                       
                        <div class="row">
                           <div class="col-lg-12" style="margin-top: 75px;">

                            <div class="col-lg-6">
                               <center><span style="font-size: 42px;">Banner Add</span></center>
                              <form action="pages/banner/saveBanner.php" method="post" enctype="multipart/form-data">
                              <div class="row">
                                <div class="col">
                                  <input type="text" name="title" class="form-control" placeholder="Banner Title" required=""><br>
                                  <input type="text" name="discount" class="form-control" placeholder="Discount" required=""><br>
                                  <input name="image" type="file"  class="form-control" required="">
                                </div><br>
                                <center>
                                    <button name="banner" class="btn btn-success">Save</button>
                                    <a href="?route=pages/viewBanner" class="btn btn-success">View</a>

                                </center>
                              </div>
                            </form>
                        </div>
                        </div>
                      </div>
                    </div>
                     <!-- End Form Elements -->
            </div>