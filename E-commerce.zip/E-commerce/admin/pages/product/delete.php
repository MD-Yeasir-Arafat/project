<?php
session_start();
include '../../../db/db.php';
$id=$_GET['id'];
$query="DELETE FROM product WHERE id=$id";
$delete=mysqli_query($db,$query);
if($delete > 0){
	$_SESSION['message']='Data has been Update';
	header('location:../../?route=pages/viewProduct');
}else{
	$_SESSION['message']='Data not Updated';
	header('location:../../?route=pages/viewProduct');
}
?>