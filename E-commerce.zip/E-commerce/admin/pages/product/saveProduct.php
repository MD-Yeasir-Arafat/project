<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['save'])){
foreach ($_POST as $key => $value) {
	$$key = $value;
}
$image=$_FILES['image']['name'];

$imageSize=$_FILES['image']['size'];

if($imageSize < 1000000){
	
	$path="../../../product_image/$image";
	$uplode=move_uploaded_file($_FILES['image']['tmp_name'],$path);
	if($uplode > 0){
		$query="INSERT INTO product(fk_cetagory_id,fk_subcetagory_id,fk_item_id,product_name,product_details,product_price,product_size,product_color,image,status) VALUES ('$cat','$subcat','$item','$product_name','$product_details','$price','$size','$color','$image',1)";
		$insert=mysqli_query($db,$query);
		if($insert >0){
			$_SESSION['message']='Data has been Insert';
			header('location:../../?route=pages/product');
		}else{
			$_SESSION['message']='Data not  Inserted';
			header('location:../../?route=pages/product');
		}
	}



}else{
	echo "File Is Very large out of 1 megabyte";
}


}
?>