<?php
include '../db/db.php';
$query="SELECT * FROM category";
$selectCat=mysqli_query($db,$query);
?>