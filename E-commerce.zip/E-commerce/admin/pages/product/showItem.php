<?php
include '../../../db/db.php';
 $id=$_POST['id'];
 $itemquery="SELECT * FROM item WHERE sub_cetagory_id='$id'";
 $selectitem=mysqli_query($db,$itemquery);
?>

<?php while($item=mysqli_fetch_assoc($selectitem)){?>
<option value="<?php echo $item['id']?>"><?php echo $item['item_name']?></option>
<?php }?>