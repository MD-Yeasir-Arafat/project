<?php
include '../../../db/db.php';
$id=$_POST['id'];
$subquery="SELECT * FROM sub_cetagory WHERE fk_cetagory_id='$id'";
$selectQuery=mysqli_query($db,$subquery);
?>
<option value="0">select sub Category</option>
<?php
	while($subcat=mysqli_fetch_assoc($selectQuery)){
?>
<option value="<?php echo $subcat['id']?>"><?php echo $subcat['sub_cetagory_name']?></option>
<?php }?>