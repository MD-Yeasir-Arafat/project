<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['update'])){
foreach ($_POST as $key => $value) {
	$$key = $value;
}

$image=$_FILES['image'];
$imageSize=$_FILES['image']['size'];
if($imageSize < 1000000){
	$date=date('hms');
	$imageFile= $date.".jpg";
	$path="../../../product_image/$imageFile";
	$uplode=move_uploaded_file($_FILES['image']['tmp_name'],$path);
	if($uplode > 0){
		$upquery="UPDATE product SET fk_cetagory_id='$cat',fk_subcetagory_id='$subcat',fk_item_id='$item',product_name='$productname',product_details='$product_details',product_price='$price',product_size='$size',product_color='$color',image='$imageFile',status=1 WHERE id='$productID'";
		
		$updatequery=mysqli_query($db,$upquery);
		
		if($updatequery > 0){
			$_SESSION['message']='Data has been update';
			header('location:../../?route=pages/viewProduct');
		}else{
			$_SESSION['message']='Data not Inserted';
			header('location:../../?route=pages/viewProduct');
		}
	}
}else{
	echo "File Is Very large out of 1 megabyte";
}


}

?>