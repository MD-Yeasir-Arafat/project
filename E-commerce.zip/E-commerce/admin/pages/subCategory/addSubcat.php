<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['save'])){
 $cat=$_POST['category'];
 $subcat=$_POST['subcategory'];

 $query="INSERT INTO sub_cetagory( fk_cetagory_id, sub_cetagory_name, status) VALUES ('$cat','$subcat',1)";
 $insert=mysqli_query($db,$query);
 if($insert > 0){
 	$_SESSION['message']='Datqa has been Insert';
 	header('location:../../?route=pages/addSubcategory');
 }else{
 	$_SESSION['message']='Datqa not Insert';
 	header('location:../../?route=pages/addSubcategory');
 }
}
?>