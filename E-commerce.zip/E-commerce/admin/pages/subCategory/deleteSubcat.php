<?php 
session_start();
include '../../../db/db.php';
$id=$_GET['id'];
$deletequery="DELETE FROM sub_cetagory WHERE id='$id'";
$delete=mysqli_query($db,$deletequery);

if($delete > 0){
	$_SESSION['message']='Data has been delete';
	header('location:../../?route=pages/viewsubCastegory');
}else{
	$_SESSION['message']='Data not deleted';
	header('location:../../?route=pages/viewsubCastegory');
}
?>