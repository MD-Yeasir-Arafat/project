<?php 
	include 'modalCategoryshow.php';
	include 'showModalSubCat.php';
?>
<form action="pages/subCategory/saveEditsubcat.php" method="post">
	<input type="hidden" name="id" value="<?php echo $data2['id']?>">
	Category:
	<select name="catnm">
		<option>Select Category</option>
		<?php while($data1=mysqli_fetch_assoc($select)){?>
		<option value="<?php echo $data1['id']?>"><?php echo $data1['category_name']?></option>
		<?php }?>
	</select>
	Sub Category:
	<input type="text" name="subCatNm" value="<?php echo $data2['sub_cetagory_name']?>">
	<input type="Submit" name="save" value="Update" class="btn btn-info">
</form>