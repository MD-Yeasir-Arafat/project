<?php
include '../../../db/db.php';
$query="SELECT * FROM category WHERE status=1";
$select=mysqli_query($db,$query);

?>