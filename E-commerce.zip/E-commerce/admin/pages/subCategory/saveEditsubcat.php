<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['save'])){
	$id=$_POST['id'];
	$cat=$_POST['catnm'];
	$subcat=$_POST['subCatNm'];

	$upquery="UPDATE sub_cetagory SET fk_cetagory_id='$cat',sub_cetagory_name='$subcat' WHERE id='$id'";
	$update=mysqli_query($db,$upquery);

	if($update > 0){
		$_SESSION['message']='Data has been update';
		header('location:../../?route=pages/viewsubCastegory');
	}else{
		$_SESSION['message']='Data not updated';
		header('location:../../?route=pages/viewsubCastegory');
	}
}
?>