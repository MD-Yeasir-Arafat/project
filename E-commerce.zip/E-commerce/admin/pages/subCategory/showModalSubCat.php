<?php
include '../../../db/db.php';
 $id=$_GET['id'];
 $querySerch="SELECT * FROM sub_cetagory WHERE id= $id";
 $serch=mysqli_query($db,$querySerch);
 $data2=mysqli_fetch_assoc($serch);
?>