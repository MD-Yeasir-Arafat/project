<?php
include '../db/db.php';
$query="SELECT category.category_name, sub_cetagory.* FROM sub_cetagory LEFT JOIN category ON sub_cetagory.fk_cetagory_id=category.id";
$subSelect=mysqli_query($db,$query);


?>