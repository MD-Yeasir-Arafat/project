 
 <?php 
include 'banner/showBanner.php';
 ?>

 <div class="row">
	<!-- Page Header -->
	<div class="col-lg-12">
	    <h1 class="page-header">Banner view</h1>
	    <center><span>
	    	<?php
	    	if(isset($_SESSION['message'])){
	    		echo $_SESSION['message'];
	    	}
	    	unset($_SESSION['message']);
	    	?>
	    </span></center>
	    <table class="table">
		  <thead>
		    <tr>
		      <th scope="col">Sl no.</th>
		      <th scope="col">Title</th>
		      <th scope="col">Discount</th>
		      <th scope="col">Banner Picture</th>
		      <th scope="col">Action</th>
		    </tr>
		  </thead>
		  <tbody>
		  	<?php
		  		while($data=mysqli_fetch_assoc($select)){
		  	?>
		    <tr>
		      <td><?php echo $data['id']?></td>
		      <td><?php echo $data['banner_title']?></td>
		       <td><?php echo $data['discount']?></td>
		      <td><img src="../bannerimage/<?php echo $data['image']?>" height="250" width="300"></td>
		      <td>
		      	<?php
		      		if($data['status'] == 1){
		      	?>
		      	<a href="pages/banner/active.php?id=<?php echo $data['id']?>&&status=deactive" class="btn btn-success">Active</a>
		      	<?php }else{?>
		      		<a href="pages/banner/active.php?id=<?php echo $data['id']?>&&status=active" class="btn btn-danger">Deactive</a>
		      		<?php }?>
		      		<a href="?route=pages/Editbanner&&id=<?php echo $data['id']?>" class="btn btn-success">Edit</a>
		      		<a href="pages/banner/delete.php?id=<?php echo $data['id']?>" class="btn btn-success">Delete</a>
		      </td>
		    </tr>
		    <?php }?>
		  </tbody>
		</table>
	</div>
	<!--End Page Header -->
</div>