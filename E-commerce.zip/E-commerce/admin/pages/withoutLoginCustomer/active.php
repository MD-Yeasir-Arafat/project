<?php 
session_start();
include '../../../db/db.php';
 $email=$_GET['email'];
 $id=$_GET['id'];
 $status=$_GET['status'];
if($status == 'inactive'){
	 $sql="UPDATE sell_producr SET status=0 WHERE id=$id";
	 $update=mysqli_query($db,$sql);
	 if($update > 0){
	 	$_SESSION['message']='Order complete';
	 	header("location:../../?route=pages/withoutloginCustomerorderList&&email=".$email."");
	 }else{
	 	$_SESSION['message']='Data not update';
	 	header("location:../../?route=pages/withoutloginCustomerorderList&&email=".$email."");
	 }
}

if($status == 'active'){
	 $sql="UPDATE sell_producr SET status=1 WHERE id=$id";
	 $update=mysqli_query($db,$sql);
	 if($update > 0){
	 	$_SESSION['message']='Data update';
	 	header("location:../../?route=pages/withoutloginCustomerorderList&&email=".$email."");
	 }else{
	 	$_SESSION['message']='Data not update';
	 	header("location:../../?route=pages/withoutloginCustomerorderList&&email=".$email."");
	 }
}

?>