<?php
include '../db/db.php';
$sql="SELECT * FROM sell_producr";
$select=mysqli_query($db,$sql);

?>