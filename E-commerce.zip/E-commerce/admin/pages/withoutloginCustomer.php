<?php 
include 'withoutLoginCustomer/showInformation.php';
?>
<div class="row">
                <!--page header-->
                <div class="col-lg-12">
                    <h1 class="page-header">customer Information</h1>
                </div>
                 <!--end page header-->
            </div>
            <?php
           $i=0;
            while($order=mysqli_fetch_assoc($select)){
             $i++;
           ?>
        <div class="row">

          <div class="col-lg-12">

            <div class="panel panel-default">
             <span><?php echo $i?></span>
              <div class="panel-body">
          
          <form>
              <div class="form-row">
                <div class="form-group">
                  <center><label for="inputAddress">Email</label></center>
                  <center><input type="email" class="form-control" id="inputEmail4" value="<?php echo $order['email']?>" style="width: 500px; text-align: center;" readonly></center>
               </div>
                
              </div>
               
                 <table class="table">
                      <thead>
                        <tr>
                          
                          <th scope="col">First name</th>
                          <th scope="col">last name</th>
                          <th scope="col">Email</th>
                          <th scope="col">phone</th>
                          <th scope="col">Address</th>
                         
                          <th scope="col">Create time</th>
                          <th scope="col">order list</th>

                        </tr>
                      </thead>
                      <tbody>
                        
                        <tr>
                          
                          <td><?php echo $order['first_name']?></td>
                          <td><?php echo $order['last_name']?></td>
                          <td><?php echo $order['email']?></td>
                          <td><?php echo $order['tel']?></td>
                          <td><?php echo $order['address']?></td>
                          
                          <td><?php echo $order['created_at']?></td>
                          <td><a href="?route=pages/withoutloginCustomerorderList&&email=<?php echo $order['email']?>" class="btn btn-info">Order List</a></td>
                        </tr>
                        
                      </tbody>
                    </table>
            </form>
                          
            </div>
              
        </div>
    </div>
</div>
<?php }?>