<?php 
include 'withoutLoginCustomer/customerOrderInfo.php';
?>
<div class="row">
                <!--page header-->
                <div class="col-lg-12">
                    <h1 class="page-header">Single customer order list</h1>
                    <center><span style="color: green; font-size: 32px;">
                      <?php 
                        if(isset($_SESSION['message'])){
                          echo $_SESSION['message'];
                        }
                        unset($_SESSION['message']);
                      ?>
                    </span></center>
                </div>
                 <!--end page header-->
            </div>
          
  <div class="row">
          <div class="col-lg-12">
            <div class="panel panel-default">
             
              <div class="panel-body">

          <form>
              <div class="form-row">
                <div class="form-group">
                  <center><label for="inputAddress">Email</label></center>
                  <center><input type="email" class="form-control" id="inputEmail4" value="<?php echo $email?>" style="width: 500px; text-align: center;" readonly></center>
               </div>
                
              </div>
               
                 <table class="table">
                      <thead>
                        <tr>
                          <th scope="col">SL</th>
                          <th scope="col">Product Picture</th>
                          <th scope="col">Product Name</th>
                          <th scope="col">price</th>
                          <th scope="col">quantity</th>
                          <th scope="col">sub Total</th>
                          <th scope="col">order time</th>
                          <th scope="col">Action</th>

                        </tr>
                      </thead>
                      <tbody>
                      <?php
                      mysqli_data_seek($query,0);
                      $a=0;
                      while($data1=mysqli_fetch_assoc($query)){
                        $a++;
                      ?>
                      <?php
                      while($data3=mysqli_fetch_assoc($product[$a])){
                      ?>
                        <tr>
                          <td><?php echo $a;?></td>
                          <td><img src="../product_image/<?php echo $data3['image']?>" height="80" width="100"></td>
                          <td style="width: 250px;"><?php echo $data3['product_name']?></td>
                          <td><input type="text" readonly value="<?php echo $data3['product_price']?>" style="width:100px;"></td>
                          <td><input type="text" readonly value="<?php echo $data1['quntity']?>" style="width:100px;"></td>
                          <?php $total=$data3['product_price']*$data1['quntity']?>
                          <td><input type="text" readonly value="<?php echo $total ?>" style="width:100px;"></td>
                          <td><?php echo $data1['created_at']?></td>
                          <td>
                            <?php
                            if($data1['status']==1){
                            ?>
                            <a href="pages/withoutLoginCustomer/active.php?id=<?php echo $data1['id']?>&&status=inactive&&email=<?php echo $data1['email']?>" class="btn btn-success">Uncomplete</a>
                            <?php }else{?>
                              <a href="pages/withoutLoginCustomer/active.php?id=<?php echo $data1['id']?>&&status=active&&email=<?php echo $data1['email']?>" class="btn btn-danger">Complete</a>
                              <?php }?>
                          </td>
                        </tr>
                       <?php
                     }}
                     mysqli_data_seek($product[$a],1);
                       ?>
                      </tbody>
                    </table>
            </form>
                          
            </div>
              
        </div>
    </div>
</div>



