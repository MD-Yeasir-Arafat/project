<?php
$db=mysqli_connect('localhost','root','','project') or die("Database not connect");
?>