<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['chack'])){

	$email=$_POST['email'];
	$pass=$_POST['pass'];
	$password=base64_encode($pass);

	$sql="SELECT * FROM customer WHERE email='$email'";
	$select=mysqli_query($db,$sql);
	$data=mysqli_fetch_assoc($select);
	if($data['email'] == $email && $data['password'] == $password)
	{
		$_SESSION['post']=$_POST;
		$_SESSION['logstatus']=true;
		header('location:../../account.php');
	}else{
		$_SESSION['message']='Email or Password is not correct';
		header('location:../index.php');
	}

}

?>