<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['forgotpass'])){

	$email=$_POST['email'];
	$sql="SELECT * FROM customer WHERE email='$email'";
	$query=mysqli_query($db,$sql);
	$fetch=mysqli_fetch_assoc($query);

	if($fetch['email'] == $email){
		$_SESSION['data']=$fetch['email'];
		header('location:../forgotpassword2.php');
	}else{
		$_SESSION['message']='Wrong! email';
		header('location:../forgotpassword1.php');
	}


	
}
?>