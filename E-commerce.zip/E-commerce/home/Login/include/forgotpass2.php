<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['forgotpass'])){

	$email=$_POST['email'];
	$password=$_POST['pass'];
	$pass=base64_encode($password);

	$sql="UPDATE customer SET password='$pass' WHERE email='$email'";
	$update=mysqli_query($db,$sql);
	if($update > 0){
		$_SESSION['message']='Your password has been update. Now login';
		header('location:../index.php');
	}else{
		$_SESSION['message']='Your password Updated';
		header('location:../forgotpassword2.php');
	}
}
?>