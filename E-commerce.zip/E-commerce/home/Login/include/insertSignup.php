<?php
session_start();
include '../../../db/db.php';
if(isset($_POST['save'])){
	foreach ($_POST as $key => $value) {
		$$key = $value;
	}
	if($pass==$cpass){
		$password=base64_encode($pass);

		 $sql="INSERT INTO customer(first_name, last_name, email, password, phone, address, city, division, country) VALUES ('$Firstname','$Lastname','$email','$password','$Phone','$address','$city','$division','$country')";
		 
		 $insert=mysqli_query($db,$sql);

		 if($insert > 0){
		 	$_SESSION['message']="Successfully Your information has been insert";
		 	header('location:../signup.php');
		 }else{
		 	$_SESSION['message']="Your Information not inserted";
		 	header('location:../signup.php');
		 }


	}else{
		$_SESSION['message']="Password And confirm not match";
		 	header('location:../signup.php');
	}
	
}
?>