<?php include 'include/categoryMenu.php';?>
<div class="category-nav show-on-click">
					<span class="category-header">Categories <i class="fa fa-list"></i></span>
					<ul class="category-list">
						<!--  -->
						<?php
						while($category=mysqli_fetch_assoc($select)){
						?>
							<li class="dropdown side-dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true"><?php echo $category['category_name']?><i class="fa fa-angle-right"></i></a>
							<div class="custom-menu">
								<div class="row">
									<?php
									mysqli_data_seek($subSelect,0); 
									$a=0;
									while($Subcategory=mysqli_fetch_assoc($subSelect)){
										$a++;
										if($category['id']==$Subcategory['fk_cetagory_id']){
									
									?>
									<div class="col-md-4">
										<ul class="list-links">
											<li>
												<h3 class="list-links-title">
													<a href="">
													<?php echo $Subcategory['sub_cetagory_name']?>
													</a>
												</h3>
											</li>
											<?php 
											while($items=mysqli_fetch_assoc($item[$a])){
											?>
											<li><a href="product.php?&&id=<?php echo $items['id']?>"><?php echo $items['item_name']?></a></li>
											
											<?php }?>
											<li><a href="allSubCategory.php" style="color:blue;">View All</a></li>
										</ul>
										<hr>
									</div>
									<?php 
										}
									}
									mysqli_data_seek($subSelect,1);
								?>
									
								</div>
								
							</div>
						</li>
						<?php }?>
						<!--  -->
						
					</ul>
				</div>