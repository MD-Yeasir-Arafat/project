<?php
session_start();
if(isset($_SESSION['logstatus'])){
	if($_SESSION['logstatus'] == true){

		include 'include/userprofile.php';
		include 'include/userorder.php';
	

?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>Account dashbord</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css" />
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css" />

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="css/nouislider.min.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<!-- HEADER -->
	<?php include '_partial/accountHeader.php';?>
	<!-- /HEADER -->

	<!-- NAVIGATION -->
	<div id="navigation">
		<!-- container -->
		<div class="container">
			<div id="responsive-nav">
				<!-- category nav -->
				<?php include '_partial/categorymenu2.php';?>
				<!-- /category nav -->

				<!-- menu nav -->
				<?php include '_partial/headermenu.php';?>
				<!-- menu nav -->
			</div>
		</div>
		<!-- /container -->
	</div>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="index.php">Home</a></li>
				<li class="active">Account Deshbord</li>
				<center><span style="color:green;"><?php 
					if(isset($_SESSION['message'])){
						echo $_SESSION['message'];
					}
					unset($_SESSION['message']);
				?></span></center>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
		<div class="container" style="margin-top: 35px; margin-bottom: 35px;">
		  

		  <ul class="nav nav-tabs">
		    <li class="active"><a data-toggle="tab" href="#home">My Profile</a></li>
		    <li><a data-toggle="tab" href="#menu1">My Address</a></li>
		    <li><a data-toggle="tab" href="#menu2">My order</a></li>
		    
		  </ul>

		  <div class="tab-content" style="margin-top: 35px;">
		    <div id="home" class="tab-pane fade in active">
		     
		     <div class="container">
		     		<?php
		     			if(!empty($fetch)){

		     		?>
					<form>
					  <div class="form-row">
					    <div class="form-group col-md-6">
					      <label for="inputEmail4">First Name:</label>
					      <input type="text" class="form-control" id="inputEmail4" readonly value="<?php echo $fetch['first_name']?>">
					    </div>
					    <div class="form-group col-md-6">
					      <label for="inputPassword4">Last name:</label>
					      <input type="text" class="form-control" id="inputPassword4" readonly value="<?php echo $fetch['last_name']?>">
					    </div>
					     <div class="form-group col-md-6">
					      <label for="inputEmail4">Email:</label>
					      <input type="email" class="form-control" id="inputEmail4" readonly value="<?php echo $fetch['email']?>">
					    </div>
					    <div class="form-group col-md-6">
					      <label for="inputPassword4">Password:</label>
					      <input type="password" class="form-control" id="password" readonly value="<?php echo base64_decode($fetch['password'])?>">
					      <input type="checkbox" onclick="myFunction()">Show Password
					    </div>
					     <div class="form-group col-md-6">
					      <label for="inputEmail4">Phone:</label>
					      <input type="text" class="form-control" id="inputEmail4"  readonly value="<?php echo $fetch['phone']?>">
					    </div>
					  </div>
					  
					  <div class="form-group col-md-12">
					      
					      <input type="submit" class="btn btn-success" id="inputEmail4" value="Edit">
					    </div>
					
					 
					</form>

				</div>
		   
		      
		    </div>
		    <div id="menu1" class="tab-pane fade">
		    	<form>
					  <div class="form-row">
					    <div class="form-group col-md-6">
					      <label for="inputEmail4">Address:</label>
					      <textarea class="form-control" id="inputEmail4" readonly ><?php echo $fetch['address']?></textarea>
					    </div>
					    <div class="form-group col-md-6">
					      <label for="inputPassword4">City:</label>
					      <input type="text" class="form-control" id="inputPassword4" readonly value="<?php echo $fetch['city']?>">
					    </div>
					     <div class="form-group col-md-6">
					      <label for="inputEmail4">Division:</label>
					      <input type="text" class="form-control" id="inputEmail4" readonly value="<?php echo $fetch['division']?>">
					    </div>
					    <div class="form-group col-md-6">
					      <label for="inputPassword4">Country:</label>
					      <input type="text" class="form-control" id="inputPassword4" readonly value="<?php echo $fetch['country']?>">
					    </div>
					    
					  </div>
					 
					  <div class="form-group col-md-12">
					      
					      <input type="submit" class="btn btn-success" id="inputEmail4" value="Edit">
					    </div>
					
					 
					</form>
					<?php }?>
		    </div>
		    <div id="menu2" class="tab-pane fade">
		      <div class="container">
		      <table class="table">
				  <thead>
				    <tr>
				      <th scope="col">order NO.</th>
				      <th scope="col">Image</th>
				      <th scope="col">name</th>
				      <th scope="col">price</th>
				      <th scope="col">Quantity</th>
				      <th scope="col">Sub Total</th>
				      <th scope="col">Action</th>
				      
				    </tr>
				  </thead>
				  <tbody>
				  	<?php 
				  	mysqli_data_seek($selectemail,0);
				  	$i=0;
				  	while($fetch2=mysqli_fetch_assoc($selectemail)){
				  		$i++;
				  	?>
				    <tr>
				      <td><?php echo $fetch2['id']?></td>
				      <?php 
				      while($fetch3=mysqli_fetch_assoc($pro[$i])){
				      ?>
				      <td><img src="../product_image/<?php echo $fetch3['image']?>" height="80" width="80"></td>
				      <td style="width: 200px;"><?php echo $fetch3['product_name']?></td>
				      <td><?php echo $fetch3['product_price']?></td>
				      <?php $st=($fetch3['product_price']*$fetch2['quentity'])?>
				      <?php }
				      mysqli_data_seek($pro[$i],1);
				      ?>
				      <td><?php echo $fetch2['quentity']?></td>
				      <td><?php echo $st?></td>
				      <td>
				      	<a href="include/userremoveorder.php?id=<?php echo $fetch2['id']?>" class="btn btn-success">Remove</a>
				      </td>
				    </tr>
				    <?php }?>
				  </tbody>
				</table>
		  	</div>
		    </div>
		    
		  </div>
		</div>
	<!-- /section -->

	<!-- FOOTER -->
	<?php include '_partial/footer.php';?>
	<!-- /FOOTER -->

	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>
<script>
	function myFunction() {
	    var x = document.getElementById("password");
	    if (x.type === "password") {
	        x.type = "text";
	    } else {
	        x.type = "password";
	    }
	}
</script>

</body>

</html>
<?php 
}else{
	$_SESSION['message']='Please Login first';
	header('location:Login/');
}
 }
?>
