<header>
		<!-- top Header -->
		<div id="top-header">
			<div class="container">
				<div class="pull-left">
					<span>ব্রিলিয়েন্ট মার্কেটে স্বাগতম!</span>
				</div>
				<div class="pull-right">
					<ul class="header-top-links">
						<li><a href="#">দোকান</a></li>
						<li><a href="#">নিউজলেটার</a></li>
						
						<li class="dropdown default-dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">ভাষা
 <i class="fa fa-caret-down"></i></a>
							<ul class="custom-menu">
								<li><a href="../">English</a></li>
								
							</ul>
						</li>
						
					</ul>
				</div>
			</div>
		</div>
		<!-- /top Header -->

		<!-- header -->
		<div id="header">
			<div class="container">
				<div class="pull-left">
					<!-- Logo -->
					<div class="header-logo">
						<a class="logo" href="index.php">
							<img src="./img/logo.png" alt="">
						</a>
					</div>
					<!-- /Logo -->

					<!-- Search -->
					<div class="header-search">
						<form>
							<input class="input search-input" type="text" placeholder="আপনার কিওয়ার্ড লিখুন">
							
							<button class="search-btn"><i class="fa fa-search"></i></button>
						</form>
					</div>
					<!-- /Search -->
				</div>
				<div class="pull-right">
					<ul class="header-btns">
						<!-- Account -->
						<li class="header-account dropdown default-dropdown">
							<div class="dropdown-toggle" role="button" data-toggle="dropdown" aria-expanded="true">
								<div class="header-btns-icon">
									<i class="fa fa-user-o"></i>
								</div>
								<strong class="text-uppercase">আমার অ্যাকাউন্ট <i class="fa fa-caret-down"></i></strong>
							</div>
							<a href="#" class="text-uppercase">লগইন</a> / <a href="#" class="text-uppercase">যোগদান</a>
							<ul class="custom-menu">
								<li><a href="#"><i class="fa fa-user-o"></i> আমার অ্যাকাউন্ট</a></li>
								<li><a href="#"><i class="fa fa-heart-o"></i>আমার ইচ্ছাগুলি</a></li>
								<li><a href="#"><i class="fa fa-exchange"></i>কম্পেয়ের </a></li>
								<li><a href="#"><i class="fa fa-check"></i>চেক আউট </a></li>
								<li><a href="#"><i class="fa fa-unlock-alt"></i> লগইন</a></li>
								<li><a href="#"><i class="fa fa-user-plus"></i> একটি অ্যাকাউন্ট তৈরি করুন</a></li>
							</ul>
						</li>
						<!-- /Account -->

						<!-- Cart -->
						<li class="header-cart dropdown default-dropdown">
							<a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
								<div class="header-btns-icon">
									<i class="fa fa-shopping-cart"></i>
									<span class="qty">3</span>
								</div>
								<strong class="text-uppercase">আমার কার্ট:</strong>
								<br>
								
							</a>
							<div class="custom-menu">
								<div id="shopping-cart">
									
									<div class="shopping-cart-btns">
										<button class="main-btn"><a href="shoppingCart.php">কার্ট দেখুন</a></button>
										
									</div>
								</div>
							</div>
						</li>
						<!-- /Cart -->

						<!-- Mobile nav toggle-->
						<li class="nav-toggle">
							<button class="nav-toggle-btn main-btn icon-btn"><i class="fa fa-bars"></i></button>
						</li>
						<!-- / Mobile nav toggle -->
					</ul>
				</div>
			</div>
			<!-- header -->
		</div>
		<!-- container -->
	</header>