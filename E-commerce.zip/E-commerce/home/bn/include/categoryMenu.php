<?php
include '../../db/db.php';
$query="SELECT * FROM category WHERE status=1";
$select=mysqli_query($db,$query);

//----------subcategory-----------

$subquery="SELECT * FROM sub_cetagory";
$subSelect=mysqli_query($db,$subquery);
$a=0;
while($data2=mysqli_fetch_assoc($subSelect)){
	$a++;
	$subId=$data2['id'];
	$itemQuery="SELECT * FROM item WHERE sub_cetagory_id=$subId  LIMIT 5";
	$item[$a]=mysqli_query($db,$itemQuery);
}



?>