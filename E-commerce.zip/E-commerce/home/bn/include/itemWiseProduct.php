<?php
include '../../db/db.php';
$id=$_GET['id'];
$query="SELECT product.*,category.category_name,sub_cetagory.sub_cetagory_name,item.item_name FROM product LEFT JOIN category ON product.fk_cetagory_id=category.id LEFT JOIN sub_cetagory ON product.fk_subcetagory_id=sub_cetagory.id LEFT JOIN item ON product.fk_item_id=item.id WHERE product.fk_item_id=$id AND product.status=1";
$selectQuery=mysqli_query($db,$query);

?>