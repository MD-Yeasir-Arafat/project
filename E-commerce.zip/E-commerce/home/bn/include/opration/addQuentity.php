<?php
session_start();
// $_SESSION['quantity']=$_POST;
include '../../../../db/db.php';

for ($i=0; $i < count($_POST['price']) ; $i++) { 
	/*$price = $_POST['price'][$i];
	$id = $_POST['id'][$i];
	$qnt = $_POST['qnt'][$i];*/

	$product[$i]['total_price']= $_POST['price'][$i];
	$product[$i]['id']= $_POST['id'][$i];
	$product[$i]['qnt']= $_POST['qnt'][$i];
}
if (isset($_POST['login'])) {
	$email = $_POST['loginEmail'];
	$password = $_POST['loginPassword'];

	$sql = "select * from customer as cs where cs.email='".$email."'' and cs.password='".$password."'";
	$data=mysqli_query($db,$sql);

}

if (isset($_POST['create'])) {
	$email = $_POST['email'];
	$password = $_POST['password'];
	$firstName = $_POST['first-name'];
	$lastName = $_POST['last-name'];
	$address = $_POST['address'];
	$city = $_POST['city'];
	$country = $_POST['country'];
	$zipCode = $_POST['zip-code'];
	$tel = $_POST['tel'];

	$insertsql = "insert into customer (email,password,first_name, last_name) values ('".$email."','".$password."','".$firstName."','".$lastName."')";
	$data=mysqli_query($db,$insertsql);
	if ($data > 0) {
		$sql = "select * from customer as cs where cs.email='".$email."' and cs.password='".$password."'";
		$userdata = mysqli_query($db,$sql);
		$user = mysqli_fetch_assoc($userdata);
		echo "<pre>"; print_r($user); exit();
		if (count($user) > 0) {
			echo "2";
			echo "<pre>"; print_r($user); exit();
			$_SESSION['user'] = $user;
		}
	}

}
$payment = $_POST['payments'];
$user_id = null;
foreach ($product as $key => $value) {
	$sql = "insert into sale_order (product_id,total_price,qnt,user_id) values (".$value['id'].",".$value['total_price'].",".$value['qnt'].",".$user_id.")";
	$data=mysqli_query($db,$sql);
	
}

?>