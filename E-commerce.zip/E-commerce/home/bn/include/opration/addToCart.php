<?php
session_start();
if(isset($_POST['btn'])){
	 
 @$num=count($_SESSION['products']);
 $num=$num+1;
 $_SESSION['products'][$num]['id']=$_POST['id'];
 $_SESSION['products'][$num]['qty']=$_POST['qty'];
}

/* echo "<pre>";
 print_r($_SESSION['products']);
unset($_SESSION['product']);
 exit();*/

 /*echo "<pre>";
 print_r($_SESSION);
 unset($_SESSION['product']);*/

 ?>
 <script type="text/javascript">
 	window.location="../../productDetails.php?&&id=<?php echo $_POST['id']?>";
 </script>