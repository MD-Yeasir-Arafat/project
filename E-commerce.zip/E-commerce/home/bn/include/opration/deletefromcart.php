<?php
@session_start();
$id=$_GET['id'];
//$key=array_search($id, $_SESSION['products']);

unset($_SESSION['products'][$id]);

?>
<script type="text/javascript">
	window.location="../../shoppingCart.php";
</script>