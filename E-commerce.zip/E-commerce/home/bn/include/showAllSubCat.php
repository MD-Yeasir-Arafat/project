<?php
include '../../db/db.php';
$query="SELECT * FROM sub_cetagory";
$selectSubcat=mysqli_query($db,$query);

$queryitem="SELECT * FROM item";
$selectitem=mysqli_query($db,$queryitem);

?>