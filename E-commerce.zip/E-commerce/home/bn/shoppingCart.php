<?php
include 'include/opration/getShoppingCart.php';
?>
<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>ব্রিলিয়েন্ট মার্কেট</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css" />
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css" />

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="css/nouislider.min.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>

	
	<!-- HEADER -->
	<?php include '_partial/header.php';?>
	<!-- /HEADER -->

	<!-- NAVIGATION -->
	<div id="navigation">
		<!-- container -->
		<div class="container">
			<div id="responsive-nav">
				<!-- category nav -->
				<?php include '_partial/categorymenu2.php';?>
				<!-- /category nav -->

				<!-- menu nav -->
				<?php include '_partial/headermenu.php';?>
				<!-- menu nav -->
			</div>
		</div>
		<!-- /container -->
	</div>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="index.php">হোম </a></li>
				<li class="active">শপিং কার্ড </li>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<form id="checkout-form" class="clearfix" action="include/opration/addQuentity.php" method="post">
					<div class="col-md-12">
						<div class="order-summary clearfix">
							<div class="section-title">
								<h3 class="title">আদেশ পর্যালোচনা</h3>
							</div>
							
							<table class="shopping-cart-table table">
								<thead>
									<tr>
										<th>আইডি </th>
										<th>ছবি </th>
										<th>পণ্যের নাম</th>
										<th class="text-center">মূল্য</th>
										<th class="text-center">পরিমাণ</th>
										<th class="text-center">মোট</th>
										<th class="text-right">Action</th>
									</tr>
								</thead>
								<tbody>
									<?php
									$i=0;
									$subtotal=0;
									if(isset($products)){
									foreach ($products as $key => $value) {
									
									?>
									<tr>
										<td><?php $i++; echo $i;?></td>
										<!-- img -->
										<td class="thumb">
											<img src="../../product_image/<?php echo $value['image']?>" alt="">
										</td>
										<!--  -->

										<!-- name -->
										<td class="details" style="width:400px; height: auto;">
											<?php echo $value['product_name']?>
										</td>
										<!--  -->

										<!-- price -->
										<td class="price text-center">
											<input type="text" name="price[]" id="price_<?php echo $i;?>" class="input" style="width:110px; height: 40px;" value="<?php echo $value['product_price']?>" disable=""> 
											<input type="hidden" name="id[]" value="<?php echo $value['id']; ?>">
										</td>
										<!--  -->

										<!-- quentity -->
										<td class="qty text-center">
											<input name="qnt[]" id="qnt_<?php echo $i;?>" class="input" type="text" value="<?php echo $value['qty']?>" onkeyup="total(<?php echo $i ?>)" style="width: 40px">
										</td>
										<!--  -->

										<!-- total -->
										<td class="total text-center">
											<input type="text" name="total[]" id="total_<?php echo $i?>" value="<?php echo $value['product_price']*$value['qty']?>" style="width: 110px; height: 40px; text-align: center;" readonly> 
										</td>
										<!--  -->

										<!-- delete -->
										<td class="text-right"><a href="include/opration/deletefromcart.php?id=<?php echo $key;?>" class="btn btn-success">Delete</a>
										</td>
										<!--  -->
									</tr>
									<?php 
									$subtotal=$subtotal+($value['product_price']*$value['qty']);
								}
							}
								?>
									
								</tbody>
								<tfoot>
									
									<tr>
										<th class="empty" colspan="3"></th>
										<th>মোট</th>
										<th colspan="2" class="total"><input id="sub_total" value="<?php echo $subtotal;?>" style=" width:150px;" disabled> টাকা</th>
									</tr>
								</tfoot>
							</table>
							<div class="pull-right">
								<button class="primary-btn">অর্ডার করুন</button>
							</div>
							
						</div>

					</div>

					<script type="text/javascript">

						function total(sl){
							var a = <?php echo $i ?>;
							var p=$('#price_'+sl).val();
							var q=$('#qnt_'+sl).val();
							var t=p*q;
							$('#total_'+sl).val(t);

							var b=0;
							var c=0;
							for(var i=1; i<=a; i++){
								b=$('#total_'+i).val();
								c=parseFloat(b)+c;

							}
								
							$('#sub_total').val(c);
						}
						
					</script>



 






					<div class="col-md-6">
						<div class="billing-details">
							
							<!-- <div class="section-title">
								<h3 class="title">Billing Details</h3>
							</div> -->
							 <ul class="nav nav-tabs">
							    <li class="active"><a data-toggle="tab" href="#login">Login</a></li>
							    <li><a data-toggle="tab" href="#create">Create Account</a></li>
							  </ul>
  							 <div class="tab-content">
							    <div id="login" class="tab-pane fade in active">
							      <br>
								     <div class="form-group">
										<input class="input" type="email" name="loginEmail" placeholder="Email">
									</div>
									<div class="form-group">
										<input class="input" type="password" name="loginPassword" placeholder="Password">
									</div>
									<div>
										<input type="submit" name="login" value="login" class="btn btn-success">
									</div>
							    </div>
							    <div id="create" class="tab-pane fade">
							    	<br>
								     <div class="form-group">
										<input class="input" type="text" name="first-name" placeholder="First Name">
									</div>
									<div class="form-group">
										<input class="input" type="text" name="last-name" placeholder="Last Name">
									</div>
									<div class="form-group">
										<input class="input" type="email" name="email" placeholder="Email">
									</div>
									<div class="form-group">
										<input class="input" type="password" name="password" placeholder="Password">
									</div>
									<div class="form-group">
										<input class="input" type="text" name="address" placeholder="Address">
									</div>
									<div class="form-group">
										<input class="input" type="text" name="city" placeholder="City">
									</div>
									<div class="form-group">
										<input class="input" type="text" name="country" placeholder="Country">
									</div>
									<div class="form-group">
										<input class="input" type="text" name="zip-code" placeholder="ZIP Code">
									</div>
									<div class="form-group">
										<input class="input" type="tel" name="tel" placeholder="Telephone">
									</div>
									<div class="form-group">
										<input type="submit" name="create" value="Create" class="btn btn-success">
									</div>
							    </div>
							 </div>



							
							<!-- <div class="form-group">
								<div class="input-checkbox">
									<input type="checkbox" id="register">
									<label class="font-weak" for="register">Create Account?</label>
									<div class="caption">
										<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt.
											<p>
												<input class="input" type="password" name="password" placeholder="Enter Your Password">
									</div>
								</div>
							</div> -->
						</div>
					</div>

					<div class="col-md-6">
						<div class="shiping-methods">
							<div class="section-title">
								<h4 class="title">Shiping Methods</h4>
							</div>
							<div class="input-checkbox">
								<input type="radio" name="shipping" id="shipping-1" checked value="free">
								<label for="shipping-1">Free Shiping -  $0.00</label>
								<div class="caption">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
										<p>
								</div>
							</div>
							<div class="input-checkbox">
								<input type="radio" name="shipping" id="shipping-2" value="stander">
								<label for="shipping-2">Standard - $4.00</label>
								<div class="caption">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
										<p>
								</div>
							</div>
						</div>

						<div class="payments-methods">
							<div class="section-title">
								<h4 class="title">Payments Methods</h4>
							</div>
							<div class="input-checkbox">
								<input type="radio" name="payments" id="payments-1" checked value="Bank">
								<label for="payments-1">Direct Bank Transfer</label>
								<div class="caption">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
										<p>
								</div>
							</div>
							<div class="input-checkbox">
								<input type="radio" name="payments" id="payments-2" value="cheque">
								<label for="payments-2">Cheque Payment</label>
								<div class="caption">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
										<p>
								</div>
							</div>
							<div class="input-checkbox">
								<input type="radio" name="payments" id="payments-3" value="Paypal">
								<label for="payments-3">Paypal System</label>
								<div class="caption">
									<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
										<p>
								</div>
							</div>
						</div>
					</div>

					
				</form>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

	<!-- FOOTER -->
	<?php include '_partial/footer.php';?>
	<!-- /FOOTER -->

	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
