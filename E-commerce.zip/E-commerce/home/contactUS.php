<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->

	<title>E-SHOP HTML Template</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Hind:400,700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Slick -->
	<link type="text/css" rel="stylesheet" href="css/slick.css" />
	<link type="text/css" rel="stylesheet" href="css/slick-theme.css" />

	<!-- nouislider -->
	<link type="text/css" rel="stylesheet" href="css/nouislider.min.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
	<!--[if lt IE 9]>
		  <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
		  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
		<![endif]-->

</head>

<body>
	<!-- HEADER -->
	<?php include '_partial/header.php';?>
	<!-- /HEADER -->

	<!-- NAVIGATION -->
	<div id="navigation">
		<!-- container -->
		<div class="container">
			<div id="responsive-nav">
				<!-- category nav -->
				<?php include '_partial/categorymenu2.php';?>
				<!-- /category nav -->

				<!-- menu nav -->
				<?php include '_partial/headermenu.php';?>
				<!-- menu nav -->
			</div>
		</div>
		<!-- /container -->
	</div>
	<!-- /NAVIGATION -->

	<!-- BREADCRUMB -->
	<div id="breadcrumb">
		<div class="container">
			<ul class="breadcrumb">
				<li><a href="index.php">Home</a></li>
				<li class="active">Blank</li>
				<center><span>
					<?php
					if(isset($_SESSION['message'])){
						echo $_SESSION['message'];
					}
					unset($_SESSION['message']);
					?>
				</span></center>
			</ul>
		</div>
	</div>
	<!-- /BREADCRUMB -->

	<!-- section -->
	<div class="section">
		<!-- container -->
		<div class="container">
			<!-- row -->
			<div class="row">
				<iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d431.1107290106214!2d90.4103464!3d23.7303872!3m2!1i1024!2i768!4f13.1!5e1!3m2!1sbn!2sbd!4v1526804568850" width="1200" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
				<div class="col-md-12" style="margin-top: 25px;">
					<hr>
					<div class="col-md-6" align="center">
					<form action="include/commentSave.php" method="post">
						 <div class="form-group">
						    <label for="exampleInputEmail1">First Name</label>
						    <input type="text" name="firstName" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter first name">
						    
						  </div>
						   <div class="form-group">
						    <label for="exampleInputEmail1">last Name</label>
						    <input type="text" name="lastName" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter last name">
						  </div>
						   <div class="form-group">
						    <label for="exampleInputEmail1">Email</label>
						    <input type="email" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email">
						  </div>
					</div>
					<div class="col-md-6">
						 <div class="form-group">
						    <label for="exampleInputEmail1">Phone</label>
						    <input type="text" name="phone" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter telephone">
						  </div>
						   <div class="form-group">
						    <label for="exampleInputEmail1">Comment</label>
						    <textarea class="form-control" placeholder="comment" name="mess"></textarea>
						  </div>
						   <div class="form-group">
						    <button class="btn btn-primary" name="save">Sent</button>
						  </div>
					</div>
					</form>
				</div>
					<div class="col-md-6">
						<div style="height:auto; width: 100%; background-color: #F6F7F6; margin-top: 35px;">
							<div>
				              <div>
				                <div>
				                  <h5>Dhaka city</h5>
				                  <address>
				                    12 Purana Paltan (4th Floor), &amp; Dhaka-1000<br>

				                    Phone :  +00 01973498888 ,<br> 
				                    Mail  :  info.ahl2u.com
				                  </address>
				                </div>
				              </div>
				            </div>
						</div>
					</div>
			</div>
			<!-- /row -->
		</div>
		<!-- /container -->
	</div>
	<!-- /section -->

	<!-- FOOTER -->
	<?php include '_partial/footer.php';?>
	<!-- /FOOTER -->

	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/slick.min.js"></script>
	<script src="js/nouislider.min.js"></script>
	<script src="js/jquery.zoom.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
