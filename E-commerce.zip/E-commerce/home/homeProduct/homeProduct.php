<?php
include '../db/db.php';
$selectsubcat="SELECT * FROM sub_cetagory WHERE status=1 ORDER BY RAND() LIMIT 15";
$selectQuery=mysqli_query($db,$selectsubcat);
$i=0;
while($fetch=mysqli_fetch_assoc($selectQuery)){
	$i++;
	$id=$fetch['id'];
	$productQuery="SELECT * FROM product WHERE fk_subcetagory_id='$id' AND status=1 ORDER BY RAND() LIMIT 4";
	$product[$i]=mysqli_query($db,$productQuery);

}

?>