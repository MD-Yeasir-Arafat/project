<?php
include '../db/db.php';
$id=$_GET['id'];
$query="SELECT product.*,item.item_name FROM product LEFT JOIN item ON product.fk_item_id=item.id WHERE product.fk_item_id=$id";
$select_query=mysqli_query($db,$query);

?>