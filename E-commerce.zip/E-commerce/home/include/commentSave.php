<?php
session_start();
include '../../db/db.php';
if(isset($_POST['save'])){
	$firstname=$_POST['firstName'];
	$lastname=$_POST['lastName'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$message=$_POST['mess'];

	$sql="INSERT INTO contactUs(first_name, last_name, email, tel, message) VALUES ('$firstname','$lastname','$email','$phone','$message')";
	$insert=mysqli_query($db,$sql);
	if($insert > 0){
		$_SESSION['message']='Your message save';
		header('location:../contactUS.php');
	}else{
		$_SESSION['message']='Your message not save';
		header('location:../contactUS.php');
	}

	
}

?>