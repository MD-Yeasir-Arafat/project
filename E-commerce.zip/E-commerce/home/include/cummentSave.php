<?php
include '../db/db.php';
if(isset($_POST['save'])){
	echo $firstname=$_POST['firstName'];
	$lastname=$_POST['lastName'];
	$email=$_POST['email'];
	$phone=$_POST['phone'];
	$message=$_POST['mess'];

	
}

?>