<?php
include '../db/db.php';
$suBquery="SELECT * FROM sub_cetagory WHERE status=1";
$selectSubcat=mysqli_query($db,$suBquery);
$a=0;
while ($data2=mysqli_fetch_assoc($selectSubcat)) {
	$a++;
	$subID=$data2['id'];
	$itemquery="SELECT * FROM item WHERE sub_cetagory_id='$subID' AND `status`=1";
	$item[$a]=mysqli_query($db,$itemquery);
}
?>