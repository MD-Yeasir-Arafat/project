<?php
session_start();
include '../../../db/db.php';

if(isset($_POST['login'])){

	$email=$_POST['loginEmail'];
	$password=$_POST['loginPassword'];
	$pass=base64_encode($password);

	 $sql="SELECT * FROM customer WHERE email='$email' AND password='$pass'";
	
	$select=mysqli_query($db,$sql);
	$fetch=mysqli_fetch_assoc($select);
	/*echo "<pre>";
	print_r($fetch);
	exit();*/
	if($fetch['email']==$email && $fetch['password']==$pass){
	
	for($i=0; $i<count($_POST['slid']); $i++){

			$product[$i]['id']=$_POST['id'][$i];
			$product[$i]['qtn']=$_POST['qnt'][$i];
			$product[$i]['email']=$_POST['loginEmail'];

	}

	foreach ($product as $key => $value) {
		$$key = $value;

		echo $sql2="INSERT INTO customerorder(email,product_id,quentity,status) VALUES ('".$value['email']."',".$value['id'].",".$value['qtn'].",1)";
		//exit();
		$save=mysqli_query($db,$sql2);
		if($save > 0){
			$_SESSION['message']='Successfully! Your order has been save';
			header('location:../../shoppingCart.php');
		}
	
	}

}else{
	$_SESSION['message']='Sorry! Your email and password not found in database. Please create a account.';
	header('location:../../shoppingCart.php');
}
}

if(isset($_POST['order'])){

$firstname=$_POST['first-name'];
$lastname=$_POST['last-name'];
$email=$_POST['email'];
$phone=$_POST['phone'];
$address=$_POST['address'];
if(empty($firstname) || empty($lastname) || empty($email) || empty($phone) || empty($address)){
	$_SESSION['message']="Please fillup all Information";
	header('location:../../shoppingCart.php');
}else{
	for($i=0; $i<count($_POST['slid']); $i++){

			$product[$i]['id']=$_POST['id'][$i];
			$product[$i]['qtn']=$_POST['qnt'][$i];
			$product[$i]['first-name']=$_POST['first-name'];
			$product[$i]['last-name']=$_POST['last-name'];
			$product[$i]['email']=$_POST['email'];
			$product[$i]['phone']=$_POST['phone'];
			$product[$i]['address']=$_POST['address'];
			

	}
	foreach ($product as $key => $value) {
		$key = $value;

		$sql3="INSERT INTO sell_producr(first_name, last_name, email, tel, address,product_id,quntity, status) VALUES ('".$value['first-name']."','".$value['last-name']."','".$value['email']."',".$value['phone'].",'".$value['address']."',".$value['id'].",".$value['qtn'].",1)";
		$insert=mysqli_query($db,$sql3);
		if($insert > 0){
			$_SESSION['message']='Successfully! Your order has been save';
			header('location:../../shoppingCart.php');
		}
	}
	/*echo "<pre>";
	print_r($product);
	exit();*/
}
}



?>