<?php
session_start();
include '../db/db.php';
$a=[];
$i=0;
if(isset($_SESSION['products'])){
	/*echo "<pre>";
	print_r($_SESSION);
	exit();*/
	foreach ($_SESSION['products'] as $key => $value) {
		
		$query="SELECT * FROM product WHERE id=".@$value['id'];
		$data=mysqli_query($db,$query);
		$products[$key]=mysqli_fetch_assoc($data);
		$products[$key]['qty']=@$value['qty'];
	}
	
}

?>