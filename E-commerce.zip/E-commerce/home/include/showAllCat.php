<?php
include '../db/db.php';
$query="SELECT * FROM category";
$select_query=mysqli_query($db,$query);

$sub_cat="SELECT * FROM sub_cetagory";
$sub_cat_query=mysqli_query($db,$sub_cat);

?>