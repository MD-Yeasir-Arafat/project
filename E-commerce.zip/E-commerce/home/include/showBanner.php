<?php
include '../db/db.php';
$sql="SELECT * FROM banner WHERE status=1";
$banner=mysqli_query($db,$sql);
?>