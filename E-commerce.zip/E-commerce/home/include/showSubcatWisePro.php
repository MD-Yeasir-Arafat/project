<?php
include '../db/db.php';
$id=$_GET['id'];
$query="SELECT product.*,sub_cetagory.sub_cetagory_name FROM product LEFT JOIN sub_cetagory ON product.fk_subcetagory_id=sub_cetagory.id WHERE product.fk_subcetagory_id=$id";
$selectQuery=mysqli_query($db,$query);
?>