<?php
session_start();
if(isset($_POST['logout'])){

	$_SESSION['logstatus']=false;
	header('location:../index.php');
}
?>