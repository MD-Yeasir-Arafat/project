 <?php
include '../db/db.php';

$data=$_SESSION['post'];
$email= $data['email'];
$Query="SELECT * FROM customerorder WHERE email='$email'";
$selectemail=mysqli_query($db,$Query);
$a=0;
while($fetchrow=mysqli_fetch_assoc($selectemail)){
	$a++;
	$proID=$fetchrow['product_id'];
	$proquery="SELECT * FROM product WHERE id=$proID";
	$pro[$a]=mysqli_query($db,$proquery);
}


?> 