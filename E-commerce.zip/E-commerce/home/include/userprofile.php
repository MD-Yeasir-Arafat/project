<?php
include '../db/db.php';

		$data=$_SESSION['post'];

		$email= $data['email'];

		$sql="SELECT * FROM customer WHERE email='$email'";
		$select=mysqli_query($db,$sql);
		$fetch=mysqli_fetch_assoc($select);
		

?>