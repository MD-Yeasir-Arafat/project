<?php
session_start();
include '../../db/db.php';
$id=$_GET['id'];
$sql="DELETE FROM customerorder WHERE id=$id";
$delete=mysqli_query($db,$sql);
if($delete > 0){
	$_SESSION['message']='Your order has been remove';
	header('location:../account.php');
}else{
	$_SESSION['message']='Your order not removed';
	header('location:../account.php');
}
?>