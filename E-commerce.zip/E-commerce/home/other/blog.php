<?php
include '../db/db.php';
$sql="SELECT * FROM aboutus_blog WHERE status=1";
$select=mysqli_query($db,$sql);
$fetch=mysqli_fetch_assoc($select);
?>