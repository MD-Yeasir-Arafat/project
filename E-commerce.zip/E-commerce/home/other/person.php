<?php
include '../db/db.php';
$sql="SELECT * FROM aboutus WHERE status=1";
$get=mysqli_query($db,$sql);


?>