<?php
header('location:home/');
?>